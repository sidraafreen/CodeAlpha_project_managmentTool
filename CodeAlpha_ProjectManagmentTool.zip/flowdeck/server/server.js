const path = require('path');
const http = require('http');
const express = require('express');
const cors = require('cors');
const { Server } = require('socket.io');

const { router: authRouter } = require('./routes/auth');
const projectsRouter = require('./routes/projects');
const tasksRouter = require('./routes/tasks');
const commentsRouter = require('./routes/comments');
const notificationsRouter = require('./routes/notifications');
const { verifyToken } = require('./auth');
const { readDb } = require('./db');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRouter);
app.use('/api/projects', projectsRouter(io));
app.use('/api/tasks', tasksRouter(io));
app.use('/api/comments', commentsRouter(io));
app.use('/api/notifications', notificationsRouter(io));

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// Fallback to index.html for any other GET (simple SPA-ish static hosting)
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'), (err) => {
    if (err) next();
  });
});

// --- Socket.io realtime layer ---
io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  const payload = token ? verifyToken(token) : null;
  if (!payload) return next(new Error('unauthorized'));
  socket.user = payload;
  next();
});

io.on('connection', (socket) => {
  socket.join(`user:${socket.user.id}`);

  socket.on('project:join', (projectId) => {
    const data = readDb();
    const project = data.projects.find(p => p.id === projectId);
    if (!project) return;
    if (project.ownerId !== socket.user.id && !project.members.includes(socket.user.id)) return;
    socket.join(`project:${projectId}`);
  });

  socket.on('project:leave', (projectId) => {
    socket.leave(`project:${projectId}`);
  });

  socket.on('typing', ({ projectId, taskId, name }) => {
    socket.to(`project:${projectId}`).emit('typing', { taskId, name });
  });
});

server.listen(PORT, () => {
  console.log(`\nFlowdeck server running: http://localhost:${PORT}\n`);
});
