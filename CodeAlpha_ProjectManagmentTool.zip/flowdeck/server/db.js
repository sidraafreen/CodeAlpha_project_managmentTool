const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'db.json');

const DEFAULT_DB = {
  users: [],
  projects: [],
  tasks: [],
  comments: [],
  notifications: []
};

function ensureDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DB, null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return { ...DEFAULT_DB };
  }
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// Very small synchronous "transaction" helper to avoid race conditions
// between concurrent requests in this simple file-backed store.
let queue = Promise.resolve();
function transact(fn) {
  queue = queue.then(async () => {
    const data = readDb();
    const result = await fn(data);
    writeDb(data);
    return result;
  });
  return queue;
}

module.exports = { readDb, writeDb, transact };
