const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const { transact, readDb } = require('../db');
const { signToken, authMiddleware } = require('../auth');

const router = express.Router();

const AVATAR_COLORS = ['#3ED9C4', '#8B7CF6', '#F0654D', '#F5B94D', '#4ADE80', '#5FA8FF'];

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, avatarColor: u.avatarColor, createdAt: u.createdAt };
}

router.post('/register', async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email and password are all required' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }
  const normalizedEmail = String(email).trim().toLowerCase();

  const result = await transact(async (data) => {
    const existing = data.users.find(u => u.email === normalizedEmail);
    if (existing) return { error: 'An account with this email already exists' };
    const passwordHash = await bcrypt.hash(password, 10);
    const user = {
      id: uuid(),
      name: name.trim(),
      email: normalizedEmail,
      passwordHash,
      avatarColor: AVATAR_COLORS[data.users.length % AVATAR_COLORS.length],
      createdAt: new Date().toISOString()
    };
    data.users.push(user);
    return { user };
  });

  if (result.error) return res.status(409).json({ error: result.error });
  const token = signToken(result.user);
  res.json({ token, user: publicUser(result.user) });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
  const normalizedEmail = String(email).trim().toLowerCase();
  const data = readDb();
  const user = data.users.find(u => u.email === normalizedEmail);
  if (!user) return res.status(401).json({ error: 'Incorrect email or password' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Incorrect email or password' });
  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
});

router.get('/me', authMiddleware, (req, res) => {
  const data = readDb();
  const user = data.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: publicUser(user) });
});

// Lookup users by name/email fragment, for inviting members to a project
router.get('/search', authMiddleware, (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!q) return res.json({ users: [] });
  const data = readDb();
  const matches = data.users
    .filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q))
    .slice(0, 8)
    .map(publicUser);
  res.json({ users: matches });
});

module.exports = { router, publicUser };
