const express = require('express');
const { v4: uuid } = require('uuid');
const { transact, readDb } = require('../db');
const { authMiddleware } = require('../auth');
const { publicUser } = require('./auth');
const { notify } = require('../notify');

module.exports = function tasksRouter(io) {
  const router = express.Router();
  router.use(authMiddleware);

  function hydrateTask(t, data) {
    const assignee = t.assigneeId ? data.users.find(u => u.id === t.assigneeId) : null;
    const commentCount = data.comments.filter(c => c.taskId === t.id).length;
    return { ...t, assignee: assignee ? publicUser(assignee) : null, commentCount };
  }

  function assertAccess(req, res, data, projectId) {
    const project = data.projects.find(p => p.id === projectId);
    if (!project) { res.status(404).json({ error: 'Project not found' }); return null; }
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      res.status(403).json({ error: 'You do not have access to this project' });
      return null;
    }
    return project;
  }

  // List tasks for a project
  router.get('/project/:projectId', (req, res) => {
    const data = readDb();
    const project = assertAccess(req, res, data, req.params.projectId);
    if (!project) return;
    const tasks = data.tasks.filter(t => t.projectId === req.params.projectId);
    res.json({ tasks: tasks.map(t => hydrateTask(t, data)) });
  });

  router.post('/project/:projectId', async (req, res) => {
    const { title, description, priority, dueDate, assigneeId, status } = req.body || {};
    if (!title || !title.trim()) return res.status(400).json({ error: 'Task title is required' });
    const result = await transact(async (data) => {
      const project = assertAccessInTx(data, req.params.projectId, req.user.id);
      if (!project) return { error: 404 };
      const col = status && project.columns.includes(status) ? status : 'todo';
      const siblingCount = data.tasks.filter(t => t.projectId === project.id && t.status === col).length;
      const task = {
        id: uuid(),
        projectId: project.id,
        title: title.trim(),
        description: (description || '').trim(),
        status: col,
        priority: priority || 'medium',
        dueDate: dueDate || null,
        assigneeId: assigneeId || null,
        order: siblingCount,
        createdBy: req.user.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      data.tasks.push(task);
      if (assigneeId && assigneeId !== req.user.id) {
        notify(data, {
          userId: assigneeId,
          message: `${req.user.name} assigned you a task: "${task.title}"`,
          link: `/board.html?id=${project.id}&task=${task.id}`
        });
      }
      return { task, project };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Project not found' });
    const data = readDb();
    const hydrated = hydrateTask(result.task, data);
    io.to(`project:${result.project.id}`).emit('task:created', hydrated);
    if (result.task.assigneeId && result.task.assigneeId !== req.user.id) {
      const n = data.notifications.filter(n => n.userId === result.task.assigneeId).slice(-1)[0];
      io.to(`user:${result.task.assigneeId}`).emit('notification:new', n);
    }
    res.status(201).json({ task: hydrated });
  });

  function assertAccessInTx(data, projectId, userId) {
    const project = data.projects.find(p => p.id === projectId);
    if (!project) return null;
    if (project.ownerId !== userId && !project.members.includes(userId)) return null;
    return project;
  }

  router.put('/:id', async (req, res) => {
    const { title, description, priority, dueDate, assigneeId } = req.body || {};
    const result = await transact(async (data) => {
      const task = data.tasks.find(t => t.id === req.params.id);
      if (!task) return { error: 404 };
      const project = assertAccessInTx(data, task.projectId, req.user.id);
      if (!project) return { error: 403 };
      const prevAssignee = task.assigneeId;
      if (title !== undefined) task.title = title.trim();
      if (description !== undefined) task.description = description.trim();
      if (priority !== undefined) task.priority = priority;
      if (dueDate !== undefined) task.dueDate = dueDate;
      if (assigneeId !== undefined) task.assigneeId = assigneeId;
      task.updatedAt = new Date().toISOString();
      if (assigneeId && assigneeId !== prevAssignee && assigneeId !== req.user.id) {
        notify(data, {
          userId: assigneeId,
          message: `${req.user.name} assigned you a task: "${task.title}"`,
          link: `/board.html?id=${project.id}&task=${task.id}`
        });
      }
      return { task, project };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Task not found' });
    if (result.error === 403) return res.status(403).json({ error: 'You do not have access to this project' });
    const data = readDb();
    const hydrated = hydrateTask(result.task, data);
    io.to(`project:${result.project.id}`).emit('task:updated', hydrated);
    if (req.body.assigneeId) {
      const n = data.notifications.filter(n => n.userId === req.body.assigneeId).slice(-1)[0];
      if (n) io.to(`user:${req.body.assigneeId}`).emit('notification:new', n);
    }
    res.json({ task: hydrated });
  });

  // Move a task to a new column / position (drag & drop)
  router.put('/:id/move', async (req, res) => {
    const { status, order } = req.body || {};
    const result = await transact(async (data) => {
      const task = data.tasks.find(t => t.id === req.params.id);
      if (!task) return { error: 404 };
      const project = assertAccessInTx(data, task.projectId, req.user.id);
      if (!project) return { error: 403 };
      task.status = status;
      task.order = typeof order === 'number' ? order : task.order;
      task.updatedAt = new Date().toISOString();
      return { task, project };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Task not found' });
    if (result.error === 403) return res.status(403).json({ error: 'You do not have access to this project' });
    const hydrated = hydrateTask(result.task, readDb());
    io.to(`project:${result.project.id}`).emit('task:moved', hydrated);
    res.json({ task: hydrated });
  });

  router.delete('/:id', async (req, res) => {
    const result = await transact(async (data) => {
      const task = data.tasks.find(t => t.id === req.params.id);
      if (!task) return { error: 404 };
      const project = assertAccessInTx(data, task.projectId, req.user.id);
      if (!project) return { error: 403 };
      data.tasks = data.tasks.filter(t => t.id !== req.params.id);
      data.comments = data.comments.filter(c => c.taskId !== req.params.id);
      return { project };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Task not found' });
    if (result.error === 403) return res.status(403).json({ error: 'You do not have access to this project' });
    io.to(`project:${result.project.id}`).emit('task:deleted', { id: req.params.id });
    res.json({ ok: true });
  });

  return router;
};
