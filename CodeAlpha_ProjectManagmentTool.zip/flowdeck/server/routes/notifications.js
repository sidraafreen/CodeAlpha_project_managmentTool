const express = require('express');
const { transact, readDb } = require('../db');
const { authMiddleware } = require('../auth');

module.exports = function notificationsRouter() {
  const router = express.Router();
  router.use(authMiddleware);

  router.get('/', (req, res) => {
    const data = readDb();
    const list = data.notifications
      .filter(n => n.userId === req.user.id)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, 50);
    res.json({ notifications: list });
  });

  router.put('/:id/read', async (req, res) => {
    await transact(async (data) => {
      const n = data.notifications.find(x => x.id === req.params.id && x.userId === req.user.id);
      if (n) n.read = true;
    });
    res.json({ ok: true });
  });

  router.put('/read-all', async (req, res) => {
    await transact(async (data) => {
      data.notifications.forEach(n => { if (n.userId === req.user.id) n.read = true; });
    });
    res.json({ ok: true });
  });

  return router;
};
