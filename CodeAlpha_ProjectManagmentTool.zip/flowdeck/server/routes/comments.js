const express = require('express');
const { v4: uuid } = require('uuid');
const { transact, readDb } = require('../db');
const { authMiddleware } = require('../auth');
const { publicUser } = require('./auth');
const { notify } = require('../notify');

module.exports = function commentsRouter(io) {
  const router = express.Router();
  router.use(authMiddleware);

  function hydrate(c, data) {
    const author = data.users.find(u => u.id === c.userId);
    return { ...c, author: author ? publicUser(author) : null };
  }

  router.get('/task/:taskId', (req, res) => {
    const data = readDb();
    const task = data.tasks.find(t => t.id === req.params.taskId);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    const project = data.projects.find(p => p.id === task.projectId);
    if (!project || (project.ownerId !== req.user.id && !project.members.includes(req.user.id))) {
      return res.status(403).json({ error: 'You do not have access to this task' });
    }
    const list = data.comments.filter(c => c.taskId === req.params.taskId)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    res.json({ comments: list.map(c => hydrate(c, data)) });
  });

  router.post('/task/:taskId', async (req, res) => {
    const { text } = req.body || {};
    if (!text || !text.trim()) return res.status(400).json({ error: 'Comment text is required' });
    const result = await transact(async (data) => {
      const task = data.tasks.find(t => t.id === req.params.taskId);
      if (!task) return { error: 404 };
      const project = data.projects.find(p => p.id === task.projectId);
      if (!project || (project.ownerId !== req.user.id && !project.members.includes(req.user.id))) {
        return { error: 403 };
      }
      const comment = {
        id: uuid(),
        taskId: task.id,
        userId: req.user.id,
        text: text.trim(),
        createdAt: new Date().toISOString()
      };
      data.comments.push(comment);
      const notifyTargets = new Set();
      if (task.assigneeId && task.assigneeId !== req.user.id) notifyTargets.add(task.assigneeId);
      if (task.createdBy && task.createdBy !== req.user.id) notifyTargets.add(task.createdBy);
      notifyTargets.forEach(uid => notify(data, {
        userId: uid,
        message: `${req.user.name} commented on "${task.title}"`,
        link: `/board.html?id=${project.id}&task=${task.id}`
      }));
      return { comment, task, project, notifyTargets: [...notifyTargets] };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Task not found' });
    if (result.error === 403) return res.status(403).json({ error: 'You do not have access to this task' });
    const data = readDb();
    const hydrated = hydrate(result.comment, data);
    io.to(`project:${result.project.id}`).emit('comment:added', hydrated);
    result.notifyTargets.forEach(uid => {
      const n = data.notifications.filter(n => n.userId === uid).slice(-1)[0];
      if (n) io.to(`user:${uid}`).emit('notification:new', n);
    });
    res.status(201).json({ comment: hydrated });
  });

  return router;
};
