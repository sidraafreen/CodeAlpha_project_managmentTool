const express = require('express');
const { v4: uuid } = require('uuid');
const { transact, readDb } = require('../db');
const { authMiddleware } = require('../auth');
const { publicUser } = require('./auth');
const { notify } = require('../notify');

module.exports = function projectsRouter(io) {
  const router = express.Router();
  router.use(authMiddleware);

  function hydrateProject(p, data) {
    const owner = data.users.find(u => u.id === p.ownerId);
    const members = p.members.map(id => data.users.find(u => u.id === id)).filter(Boolean).map(publicUser);
    const taskCount = data.tasks.filter(t => t.projectId === p.id).length;
    const doneCount = data.tasks.filter(t => t.projectId === p.id && t.status === 'done').length;
    return {
      ...p,
      owner: owner ? publicUser(owner) : null,
      members,
      taskCount,
      doneCount
    };
  }

  // List projects the current user owns or is a member of
  router.get('/', (req, res) => {
    const data = readDb();
    const mine = data.projects.filter(p => p.ownerId === req.user.id || p.members.includes(req.user.id));
    res.json({ projects: mine.map(p => hydrateProject(p, data)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)) });
  });

  router.post('/', async (req, res) => {
    const { name, description, color, icon } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: 'Project name is required' });
    const result = await transact(async (data) => {
      const project = {
        id: uuid(),
        name: name.trim(),
        description: (description || '').trim(),
        color: color || '#3ED9C4',
        icon: icon || 'folder',
        ownerId: req.user.id,
        members: [req.user.id],
        columns: ['todo', 'in_progress', 'done'],
        createdAt: new Date().toISOString()
      };
      data.projects.push(project);
      return project;
    });
    res.status(201).json({ project: hydrateProject(result, readDb()) });
  });

  function findProjectOr404(req, res, data) {
    const project = data.projects.find(p => p.id === req.params.id);
    if (!project) { res.status(404).json({ error: 'Project not found' }); return null; }
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      res.status(403).json({ error: 'You do not have access to this project' });
      return null;
    }
    return project;
  }

  router.get('/:id', (req, res) => {
    const data = readDb();
    const project = findProjectOr404(req, res, data);
    if (!project) return;
    res.json({ project: hydrateProject(project, data) });
  });

  router.put('/:id', async (req, res) => {
    const { name, description, color, icon } = req.body || {};
    const result = await transact(async (data) => {
      const project = data.projects.find(p => p.id === req.params.id);
      if (!project) return { error: 404 };
      if (project.ownerId !== req.user.id) return { error: 403 };
      if (name !== undefined) project.name = name.trim();
      if (description !== undefined) project.description = description.trim();
      if (color !== undefined) project.color = color;
      if (icon !== undefined) project.icon = icon;
      return project;
    });
    if (result.error === 404) return res.status(404).json({ error: 'Project not found' });
    if (result.error === 403) return res.status(403).json({ error: 'Only the owner can edit this project' });
    io.to(`project:${req.params.id}`).emit('project:updated', hydrateProject(result, readDb()));
    res.json({ project: hydrateProject(result, readDb()) });
  });

  router.delete('/:id', async (req, res) => {
    const result = await transact(async (data) => {
      const project = data.projects.find(p => p.id === req.params.id);
      if (!project) return { error: 404 };
      if (project.ownerId !== req.user.id) return { error: 403 };
      data.projects = data.projects.filter(p => p.id !== req.params.id);
      const removedTasks = data.tasks.filter(t => t.projectId === req.params.id).map(t => t.id);
      data.tasks = data.tasks.filter(t => t.projectId !== req.params.id);
      data.comments = data.comments.filter(c => !removedTasks.includes(c.taskId));
      return { ok: true };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Project not found' });
    if (result.error === 403) return res.status(403).json({ error: 'Only the owner can delete this project' });
    io.to(`project:${req.params.id}`).emit('project:deleted', { id: req.params.id });
    res.json({ ok: true });
  });

  // Add a member to a project by email
  router.post('/:id/members', async (req, res) => {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ error: 'Email is required' });
    const result = await transact(async (data) => {
      const project = data.projects.find(p => p.id === req.params.id);
      if (!project) return { error: 404 };
      if (project.ownerId !== req.user.id) return { error: 403 };
      const target = data.users.find(u => u.email === email.trim().toLowerCase());
      if (!target) return { error: 'no-user' };
      if (project.members.includes(target.id)) return { error: 'already-member' };
      project.members.push(target.id);
      notify(data, {
        userId: target.id,
        message: `${req.user.name} added you to project "${project.name}"`,
        link: `/board.html?id=${project.id}`
      });
      return { project, targetId: target.id };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Project not found' });
    if (result.error === 403) return res.status(403).json({ error: 'Only the owner can add members' });
    if (result.error === 'no-user') return res.status(404).json({ error: 'No user found with that email' });
    if (result.error === 'already-member') return res.status(409).json({ error: 'That person is already a member' });
    const data = readDb();
    io.to(`project:${req.params.id}`).emit('project:updated', hydrateProject(result.project, data));
    io.to(`user:${result.targetId}`).emit('notification:new', data.notifications.filter(n => n.userId === result.targetId).slice(-1)[0]);
    res.json({ project: hydrateProject(result.project, data) });
  });

  router.delete('/:id/members/:userId', async (req, res) => {
    const result = await transact(async (data) => {
      const project = data.projects.find(p => p.id === req.params.id);
      if (!project) return { error: 404 };
      if (project.ownerId !== req.user.id && req.user.id !== req.params.userId) return { error: 403 };
      if (req.params.userId === project.ownerId) return { error: 'owner' };
      project.members = project.members.filter(id => id !== req.params.userId);
      return { project };
    });
    if (result.error === 404) return res.status(404).json({ error: 'Project not found' });
    if (result.error === 403) return res.status(403).json({ error: 'Not allowed' });
    if (result.error === 'owner') return res.status(400).json({ error: 'The owner cannot be removed' });
    io.to(`project:${req.params.id}`).emit('project:updated', hydrateProject(result.project, readDb()));
    res.json({ project: hydrateProject(result.project, readDb()) });
  });

  return router;
};
