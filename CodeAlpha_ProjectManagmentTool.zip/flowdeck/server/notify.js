const { v4: uuid } = require('uuid');

// Pushes a notification object onto data.notifications (mutates the
// in-flight transaction data). Caller is responsible for emitting the
// socket event once the transaction has committed.
function notify(data, { userId, message, link }) {
  const notification = {
    id: uuid(),
    userId,
    message,
    link: link || null,
    read: false,
    createdAt: new Date().toISOString()
  };
  data.notifications.push(notification);
  return notification;
}

module.exports = { notify };
