const COLORS = ['#3ED9C4', '#8B7CF6', '#F0654D', '#F5B94D', '#4ADE80', '#5FA8FF'];
let selectedColor = COLORS[0];
let editingProjectId = null;

const colorPicker = document.getElementById('colorPicker');
colorPicker.innerHTML = COLORS.map(c => `<span class="color-swatch" data-c="${c}" style="background:${c}"></span>`).join('');
function paintColorPicker() {
  [...colorPicker.children].forEach(el => el.classList.toggle('selected', el.dataset.c === selectedColor));
}
paintColorPicker();
colorPicker.addEventListener('click', (e) => {
  if (e.target.dataset.c) { selectedColor = e.target.dataset.c; paintColorPicker(); }
});

const projectModalBackdrop = document.getElementById('projectModalBackdrop');
function openProjectModal() {
  editingProjectId = null;
  document.getElementById('projectModalTitle').textContent = 'New project';
  document.getElementById('saveProjectBtn').textContent = 'Create project';
  document.getElementById('pfName').value = '';
  document.getElementById('pfDesc').value = '';
  selectedColor = COLORS[Math.floor(Math.random() * COLORS.length)];
  paintColorPicker();
  projectModalBackdrop.classList.add('show');
  setTimeout(() => document.getElementById('pfName').focus(), 50);
}
function closeProjectModal() { projectModalBackdrop.classList.remove('show'); }

document.getElementById('newProjectBtn').addEventListener('click', openProjectModal);
document.getElementById('quickAddBtn').addEventListener('click', openProjectModal);
document.getElementById('closeProjectModal').addEventListener('click', closeProjectModal);
document.getElementById('cancelProjectModal').addEventListener('click', closeProjectModal);
projectModalBackdrop.addEventListener('click', (e) => { if (e.target === projectModalBackdrop) closeProjectModal(); });

document.getElementById('saveProjectBtn').addEventListener('click', async () => {
  const name = document.getElementById('pfName').value.trim();
  const description = document.getElementById('pfDesc').value.trim();
  if (!name) { toast('Give your project a name', 'error'); return; }
  const btn = document.getElementById('saveProjectBtn');
  btn.disabled = true;
  try {
    await Api.post('/projects', { name, description, color: selectedColor });
    toast('Project created', 'success');
    closeProjectModal();
    loadProjects();
    loadSideProjects();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

function projectCardHtml(p) {
  const pct = p.taskCount ? Math.round((p.doneCount / p.taskCount) * 100) : 0;
  const avatars = p.members.slice(0, 4).map(m => `<div class="avatar sm" style="background:${m.avatarColor}">${initials(m.name)}</div>`).join('');
  return `
    <a class="project-card" style="--card-color:${p.color}" href="/board.html?id=${p.id}">
      <div class="pc-top">
        <div class="pc-icon">${ICONS.folder}</div>
      </div>
      <div>
        <h3>${escapeHtml(p.name)}</h3>
        <p class="desc">${escapeHtml(p.description || 'No description yet.')}</p>
      </div>
      <div class="pc-progress-track"><div class="pc-progress-fill" style="width:${pct}%"></div></div>
      <div class="pc-bottom">
        <div class="avatar-stack">${avatars}</div>
        <div class="pc-meta">${p.doneCount}/${p.taskCount} done</div>
      </div>
    </a>
  `;
}

async function loadProjects() {
  const area = document.getElementById('projectsArea');
  const summary = document.getElementById('projectSummary');
  try {
    const { projects } = await Api.get('/projects');
    summary.textContent = projects.length ? `${projects.length} project${projects.length > 1 ? 's' : ''}` : 'No projects yet';
    const newCardHtml = `
      <div class="new-project-card" id="inlineNewProject">
        ${ICONS.plus}
        <span>New project</span>
      </div>`;
    if (!projects.length) {
      area.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1;">
          ${ICONS.empty}
          <h3>No projects yet</h3>
          <div>Create your first board to start assigning tasks.</div>
          <button class="btn btn-primary mt-16" id="emptyCreateBtn">${ICONS.plus} Create a project</button>
        </div>`;
      document.getElementById('emptyCreateBtn').addEventListener('click', openProjectModal);
      return;
    }
    area.innerHTML = projects.map(projectCardHtml).join('') + newCardHtml;
    document.getElementById('inlineNewProject').addEventListener('click', openProjectModal);
  } catch (e) {
    area.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><h3>Couldn't load projects</h3><div>${escapeHtml(e.message)}</div></div>`;
  }
}

loadProjects();

// Realtime: refresh grid if a project we belong to changes elsewhere
window.addEventListener('DOMContentLoaded', () => {
  const trySubscribe = () => {
    if (window.socket) {
      window.socket.on('project:updated', () => { loadProjects(); loadSideProjects(); });
      window.socket.on('project:deleted', () => { loadProjects(); loadSideProjects(); });
    } else {
      setTimeout(trySubscribe, 200);
    }
  };
  trySubscribe();
});
