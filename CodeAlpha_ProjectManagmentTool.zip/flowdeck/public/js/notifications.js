// Shared across dashboard.html and board.html: sidebar, icons, notification
// bell, and the single socket.io connection used for realtime updates.

if (!requireAuth()) { /* redirected */ }

const me = Api.currentUser();

// ---- icon injection ----
function injectIcon(id, name) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = ICONS[name];
}
injectIcon('logoSlot', 'logo');
injectIcon('icHome', 'home');
injectIcon('icBell', 'bell');
injectIcon('icPlus', 'plus');
injectIcon('icPlusSmall', 'plus');
injectIcon('icX', 'x');
injectIcon('icMenu', 'menu');
injectIcon('icLogout', 'logout');
injectIcon('icBoard', 'board');
injectIcon('icUsers', 'users');
injectIcon('icTrash', 'trash');
injectIcon('icEdit', 'edit');
injectIcon('icCalendar', 'calendar');
injectIcon('icComment', 'comment');
injectIcon('icComment2', 'comment');
injectIcon('icX2', 'x');
injectIcon('icX3', 'x');
injectIcon('icX4', 'x');
injectIcon('icTrash2', 'trash');


// ---- user chip ----
if (me) {
  const av = document.getElementById('meAvatar');
  if (av) { av.style.background = me.avatarColor || '#3ED9C4'; av.textContent = initials(me.name); }
  const nm = document.getElementById('meName'); if (nm) nm.textContent = me.name;
  const em = document.getElementById('meEmail'); if (em) em.textContent = me.email;
}
const logoutChip = document.getElementById('logoutChip');
if (logoutChip) logoutChip.addEventListener('click', () => {
  if (confirm('Log out of Flowdeck?')) {
    Api.clearToken();
    if (window.socket) window.socket.disconnect();
    window.location.href = '/index.html';
  }
});

// ---- mobile sidebar ----
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const mobileToggle = document.getElementById('mobileToggle');
if (mobileToggle) mobileToggle.addEventListener('click', () => {
  sidebar.classList.add('open'); overlay.classList.add('show');
});
if (overlay) overlay.addEventListener('click', () => {
  sidebar.classList.remove('open'); overlay.classList.remove('show');
});

// ---- side project list ----
async function loadSideProjects(activeId) {
  const list = document.getElementById('sideProjectList');
  if (!list) return;
  try {
    const { projects } = await Api.get('/projects');
    if (!projects.length) {
      list.innerHTML = `<div class="small text-muted" style="padding:10px;">No projects yet</div>`;
      return;
    }
    list.innerHTML = projects.map(p => `
      <a class="project-pill ${p.id === activeId ? 'active' : ''}" href="/board.html?id=${p.id}">
        <span class="dot" style="background:${p.color}"></span>
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(p.name)}</span>
      </a>
    `).join('');
  } catch (e) {
    list.innerHTML = `<div class="small text-muted" style="padding:10px;">Couldn't load projects</div>`;
  }
}
loadSideProjects(window.ACTIVE_PROJECT_ID || null);

// ---- notification bell ----
const bellBtn = document.getElementById('bellBtn');
const bellDot = document.getElementById('bellDot');
const notifPanel = document.getElementById('notifPanel');
const notifList = document.getElementById('notifList');

function renderNotifications(items) {
  if (!notifList) return;
  if (!items.length) {
    notifList.innerHTML = `<div class="notif-empty">You're all caught up</div>`;
    return;
  }
  notifList.innerHTML = items.map(n => `
    <a class="notif-item ${n.read ? '' : 'unread'}" href="${n.link || '#'}" data-id="${n.id}">
      <div>${escapeHtml(n.message)}</div>
      <div class="time">${timeAgo(n.createdAt)}</div>
    </a>
  `).join('');
}

async function refreshNotifications() {
  try {
    const { notifications } = await Api.get('/notifications');
    renderNotifications(notifications);
    const hasUnread = notifications.some(n => !n.read);
    if (bellDot) bellDot.classList.toggle('show', hasUnread);
  } catch (e) { /* ignore */ }
}

if (bellBtn) {
  bellBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    notifPanel.classList.toggle('show');
    if (notifPanel.classList.contains('show')) refreshNotifications();
  });
  document.addEventListener('click', (e) => {
    if (notifPanel && !notifPanel.contains(e.target) && e.target !== bellBtn) {
      notifPanel.classList.remove('show');
    }
  });
}
const markAllBtn = document.getElementById('markAllRead');
if (markAllBtn) markAllBtn.addEventListener('click', async () => {
  await Api.put('/notifications/read-all');
  refreshNotifications();
});

refreshNotifications();

// ---- socket.io realtime connection (single shared instance) ----
window.socket = io({ auth: { token: Api.token() } });
window.socket.on('notification:new', (n) => {
  if (!n) return;
  toast(n.message, 'info');
  if (bellDot) bellDot.classList.add('show');
  refreshNotifications();
});
window.socket.on('connect_error', (err) => {
  if (err && err.message === 'unauthorized') {
    Api.clearToken();
    window.location.href = '/index.html';
  }
});
