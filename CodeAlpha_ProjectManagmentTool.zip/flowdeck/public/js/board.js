const projectId = new URLSearchParams(window.location.search).get('id');
if (!projectId) window.location.href = '/dashboard.html';

const COLUMNS = [
  { key: 'todo', label: 'To do', dot: '#5FA8FF' },
  { key: 'in_progress', label: 'In progress', dot: '#8B7CF6' },
  { key: 'done', label: 'Done', dot: '#4ADE80' }
];

let project = null;
let tasks = [];
let activeTaskId = null;
let draggedTaskId = null;
let typingTimeout = null;

// ---------------- Data loading ----------------
async function loadBoard() {
  try {
    const [{ project: p }, { tasks: t }] = await Promise.all([
      Api.get(`/projects/${projectId}`),
      Api.get(`/tasks/project/${projectId}`)
    ]);
    project = p; tasks = t;
    renderHeader();
    renderColumns();
    loadSideProjects(projectId);
    if (window.socket) window.socket.emit('project:join', projectId);
  } catch (e) {
    document.getElementById('boardTitle').textContent = 'Project unavailable';
    document.getElementById('boardCrumb').textContent = e.message;
    toast(e.message, 'error');
  }
}

function renderHeader() {
  document.title = `${project.name} — Flowdeck`;
  document.getElementById('boardTitle').textContent = project.name;
  document.getElementById('boardCrumb').textContent = project.description || `${project.members.length} member${project.members.length > 1 ? 's' : ''}`;
  const avatars = project.members.slice(0, 4).map(m => `<div class="avatar sm" style="background:${m.avatarColor}" title="${escapeHtml(m.name)}">${initials(m.name)}</div>`).join('');
  document.getElementById('memberAvatars').innerHTML = avatars;
  const delBtn = document.getElementById('deleteProjectBtn');
  if (me && project.ownerId === me.id) delBtn.classList.remove('hidden'); else delBtn.classList.add('hidden');
}

function priorityLabel(p) { return p.charAt(0).toUpperCase() + p.slice(1); }

function taskCardHtml(t) {
  const priorityColor = { high: 'var(--danger)', medium: 'var(--warning)', low: 'var(--success)' }[t.priority] || 'var(--accent-2)';
  const overdue = t.dueDate && new Date(t.dueDate) < new Date(new Date().toDateString()) && t.status !== 'done';
  return `
    <div class="task-card" draggable="true" data-id="${t.id}" style="--priority-color:${priorityColor}">
      <div class="tc-title">${escapeHtml(t.title)}</div>
      ${t.description ? `<div class="tc-desc">${escapeHtml(t.description)}</div>` : ''}
      <div class="tc-tags">
        <span class="tag priority-${t.priority}">${priorityLabel(t.priority)}</span>
      </div>
      <div class="tc-footer">
        <div class="tc-meta-left">
          ${t.dueDate ? `<span class="tc-due ${overdue ? 'overdue' : ''}">${ICONS.calendar}${new Date(t.dueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>` : ''}
          ${t.commentCount ? `<span>${ICONS.comment}${t.commentCount}</span>` : ''}
        </div>
        ${t.assignee ? `<div class="avatar sm" style="background:${t.assignee.avatarColor}" title="${escapeHtml(t.assignee.name)}">${initials(t.assignee.name)}</div>` : ''}
      </div>
    </div>`;
}

function renderColumns() {
  const wrap = document.getElementById('boardColumns');
  wrap.innerHTML = COLUMNS.map(col => {
    const colTasks = tasks.filter(t => t.status === col.key).sort((a, b) => a.order - b.order);
    return `
      <div class="column" data-col="${col.key}">
        <div class="column-head">
          <div class="ch-left"><span class="column-dot" style="background:${col.dot}"></span><h4>${col.label}</h4></div>
          <span class="column-count">${colTasks.length}</span>
        </div>
        <div class="column-cards" data-col="${col.key}">
          ${colTasks.map(taskCardHtml).join('')}
        </div>
        <div class="add-card-btn" data-col="${col.key}">${ICONS.plus} Add task</div>
      </div>`;
  }).join('');

  wrap.querySelectorAll('.add-card-btn').forEach(btn => {
    btn.addEventListener('click', () => openTaskForm(btn.dataset.col));
  });
  wrap.querySelectorAll('.task-card').forEach(card => {
    card.addEventListener('click', () => openTaskDetail(card.dataset.id));
    card.addEventListener('dragstart', (e) => {
      draggedTaskId = card.dataset.id;
      card.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    card.addEventListener('dragend', () => card.classList.remove('dragging'));
  });
  wrap.querySelectorAll('.column-cards').forEach(colEl => {
    colEl.addEventListener('dragover', (e) => { e.preventDefault(); colEl.classList.add('drag-over'); });
    colEl.addEventListener('dragleave', () => colEl.classList.remove('drag-over'));
    colEl.addEventListener('drop', async (e) => {
      e.preventDefault();
      colEl.classList.remove('drag-over');
      if (!draggedTaskId) return;
      const newStatus = colEl.dataset.col;
      const t = tasks.find(x => x.id === draggedTaskId);
      if (!t) return;
      const newOrder = tasks.filter(x => x.status === newStatus).length;
      t.status = newStatus; t.order = newOrder;
      renderColumns();
      try {
        await Api.put(`/tasks/${draggedTaskId}/move`, { status: newStatus, order: newOrder });
      } catch (err) {
        toast(err.message, 'error');
        loadBoard();
      }
      draggedTaskId = null;
    });
  });
}

// ---------------- Task create/edit form ----------------
const taskFormBackdrop = document.getElementById('taskFormBackdrop');
let taskFormMode = 'create';
let taskFormColumn = 'todo';
let taskFormEditingId = null;

function populateAssigneeSelect() {
  const sel = document.getElementById('tfAssignee');
  sel.innerHTML = '<option value="">Unassigned</option>' +
    project.members.map(m => `<option value="${m.id}">${escapeHtml(m.name)}</option>`).join('');
}

function openTaskForm(column) {
  taskFormMode = 'create'; taskFormColumn = column; taskFormEditingId = null;
  document.getElementById('taskFormTitle').textContent = 'New task';
  document.getElementById('saveTaskBtn').textContent = 'Add task';
  document.getElementById('tfTitle').value = '';
  document.getElementById('tfDesc').value = '';
  document.getElementById('tfPriority').value = 'medium';
  document.getElementById('tfDue').value = '';
  populateAssigneeSelect();
  document.getElementById('tfAssignee').value = '';
  taskFormBackdrop.classList.add('show');
  setTimeout(() => document.getElementById('tfTitle').focus(), 50);
}

function openTaskFormForEdit(task) {
  taskFormMode = 'edit'; taskFormEditingId = task.id;
  document.getElementById('taskFormTitle').textContent = 'Edit task';
  document.getElementById('saveTaskBtn').textContent = 'Save changes';
  document.getElementById('tfTitle').value = task.title;
  document.getElementById('tfDesc').value = task.description || '';
  document.getElementById('tfPriority').value = task.priority;
  document.getElementById('tfDue').value = task.dueDate ? task.dueDate.slice(0, 10) : '';
  populateAssigneeSelect();
  document.getElementById('tfAssignee').value = task.assigneeId || '';
  closeTaskDetail();
  taskFormBackdrop.classList.add('show');
}

function closeTaskForm() { taskFormBackdrop.classList.remove('show'); }
document.getElementById('closeTaskForm').addEventListener('click', closeTaskForm);
document.getElementById('cancelTaskForm').addEventListener('click', closeTaskForm);
taskFormBackdrop.addEventListener('click', (e) => { if (e.target === taskFormBackdrop) closeTaskForm(); });

document.getElementById('saveTaskBtn').addEventListener('click', async () => {
  const title = document.getElementById('tfTitle').value.trim();
  if (!title) { toast('Give the task a title', 'error'); return; }
  const payload = {
    title,
    description: document.getElementById('tfDesc').value.trim(),
    priority: document.getElementById('tfPriority').value,
    dueDate: document.getElementById('tfDue').value || null,
    assigneeId: document.getElementById('tfAssignee').value || null
  };
  const btn = document.getElementById('saveTaskBtn');
  btn.disabled = true;
  try {
    if (taskFormMode === 'create') {
      payload.status = taskFormColumn;
      await Api.post(`/tasks/project/${projectId}`, payload);
      toast('Task added', 'success');
    } else {
      await Api.put(`/tasks/${taskFormEditingId}`, payload);
      toast('Task updated', 'success');
    }
    closeTaskForm();
    loadBoard();
  } catch (e) {
    toast(e.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

// ---------------- Task detail + comments ----------------
const taskDetailBackdrop = document.getElementById('taskDetailBackdrop');

function statusLabel(s) { return COLUMNS.find(c => c.key === s)?.label || s; }

async function openTaskDetail(taskId) {
  activeTaskId = taskId;
  const t = tasks.find(x => x.id === taskId);
  if (!t) return;
  document.getElementById('tdTitleText').textContent = t.title;
  document.getElementById('tdDescText').textContent = t.description || 'No description.';
  document.getElementById('tdStatusTag').textContent = statusLabel(t.status);
  document.getElementById('tdStatusTag').className = 'tag priority-low';
  const pTag = document.getElementById('tdPriorityTag');
  pTag.textContent = priorityLabel(t.priority);
  pTag.className = `tag priority-${t.priority}`;
  document.getElementById('tdAssignee').textContent = t.assignee ? t.assignee.name : 'Unassigned';
  document.getElementById('tdDue').textContent = t.dueDate ? new Date(t.dueDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'No due date';
  taskDetailBackdrop.classList.add('show');
  document.getElementById('commentInput').value = '';
  await loadComments(taskId);
}
function closeTaskDetail() { taskDetailBackdrop.classList.remove('show'); activeTaskId = null; }
document.getElementById('closeTaskDetail').addEventListener('click', closeTaskDetail);
taskDetailBackdrop.addEventListener('click', (e) => { if (e.target === taskDetailBackdrop) closeTaskDetail(); });

document.getElementById('editTaskBtn').addEventListener('click', () => {
  const t = tasks.find(x => x.id === activeTaskId);
  if (t) openTaskFormForEdit(t);
});
document.getElementById('deleteTaskBtn').addEventListener('click', async () => {
  if (!activeTaskId) return;
  if (!confirm('Delete this task? This cannot be undone.')) return;
  try {
    await Api.del(`/tasks/${activeTaskId}`);
    toast('Task deleted', 'success');
    closeTaskDetail();
    loadBoard();
  } catch (e) { toast(e.message, 'error'); }
});

function commentHtml(c) {
  return `
    <div class="comment-item">
      <div class="avatar sm" style="background:${c.author?.avatarColor || '#5FA8FF'}">${initials(c.author?.name || '?')}</div>
      <div class="comment-body">
        <div class="c-head"><span class="c-name">${escapeHtml(c.author?.name || 'Someone')}</span><span class="c-time">${timeAgo(c.createdAt)}</span></div>
        <div class="c-text">${escapeHtml(c.text)}</div>
      </div>
    </div>`;
}

async function loadComments(taskId) {
  const list = document.getElementById('commentList');
  list.innerHTML = `<div class="page-loader" style="min-height:60px;"><div class="loader"></div></div>`;
  try {
    const { comments } = await Api.get(`/comments/task/${taskId}`);
    list.innerHTML = comments.length ? comments.map(commentHtml).join('') : `<div class="small text-muted">No comments yet — start the conversation.</div>`;
    list.scrollTop = list.scrollHeight;
  } catch (e) {
    list.innerHTML = `<div class="small text-muted">Couldn't load comments.</div>`;
  }
}

async function sendComment() {
  const input = document.getElementById('commentInput');
  const text = input.value.trim();
  if (!text || !activeTaskId) return;
  input.value = '';
  try {
    await Api.post(`/comments/task/${activeTaskId}`, { text });
  } catch (e) {
    toast(e.message, 'error');
  }
}
document.getElementById('sendCommentBtn').addEventListener('click', sendComment);
document.getElementById('commentInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendComment(); }
  else if (window.socket && activeTaskId) {
    window.socket.emit('typing', { projectId, taskId: activeTaskId, name: me.name });
  }
});

// ---------------- Members modal ----------------
const membersBackdrop = document.getElementById('membersBackdrop');
function renderMemberList() {
  const wrap = document.getElementById('memberList');
  wrap.innerHTML = project.members.map(m => `
    <div class="member-row">
      <div class="avatar sm" style="background:${m.avatarColor}">${initials(m.name)}</div>
      <div class="who"><div class="name">${escapeHtml(m.name)}${m.id === project.ownerId ? ' · Owner' : ''}</div><div class="email">${escapeHtml(m.email)}</div></div>
      ${(project.ownerId === me.id && m.id !== project.ownerId) ? `<button class="btn btn-ghost btn-icon remove-member" data-id="${m.id}">${ICONS.x}</button>` : ''}
    </div>`).join('');
  wrap.querySelectorAll('.remove-member').forEach(btn => btn.addEventListener('click', async () => {
    try { await Api.del(`/projects/${projectId}/members/${btn.dataset.id}`); toast('Member removed', 'success'); loadBoard(); renderMemberList(); }
    catch (e) { toast(e.message, 'error'); }
  }));
}
document.getElementById('membersBtn').addEventListener('click', () => { renderMemberList(); membersBackdrop.classList.add('show'); });
document.getElementById('memberAvatars').addEventListener('click', () => { renderMemberList(); membersBackdrop.classList.add('show'); });
document.getElementById('closeMembersModal').addEventListener('click', () => membersBackdrop.classList.remove('show'));
membersBackdrop.addEventListener('click', (e) => { if (e.target === membersBackdrop) membersBackdrop.classList.remove('show'); });
document.getElementById('inviteBtn').addEventListener('click', async () => {
  const email = document.getElementById('inviteEmail').value.trim();
  if (!email) return;
  try {
    await Api.post(`/projects/${projectId}/members`, { email });
    document.getElementById('inviteEmail').value = '';
    toast('Member added', 'success');
    loadBoard();
    renderMemberList();
  } catch (e) { toast(e.message, 'error'); }
});

document.getElementById('deleteProjectBtn').addEventListener('click', async () => {
  if (!confirm(`Delete "${project.name}" and all of its tasks? This cannot be undone.`)) return;
  try {
    await Api.del(`/projects/${projectId}`);
    toast('Project deleted', 'success');
    window.location.href = '/dashboard.html';
  } catch (e) { toast(e.message, 'error'); }
});

// ---------------- Realtime ----------------
function subscribeSocket() {
  if (!window.socket) { setTimeout(subscribeSocket, 150); return; }
  window.socket.emit('project:join', projectId);

  window.socket.on('task:created', (t) => {
    if (t.projectId !== projectId) return;
    if (!tasks.find(x => x.id === t.id)) tasks.push(t);
    renderColumns();
  });
  window.socket.on('task:updated', (t) => {
    if (t.projectId !== projectId) return;
    tasks = tasks.map(x => x.id === t.id ? t : x);
    renderColumns();
    if (activeTaskId === t.id) openTaskDetail(t.id);
  });
  window.socket.on('task:moved', (t) => {
    if (t.projectId !== projectId) return;
    tasks = tasks.map(x => x.id === t.id ? t : x);
    renderColumns();
  });
  window.socket.on('task:deleted', ({ id }) => {
    tasks = tasks.filter(x => x.id !== id);
    renderColumns();
    if (activeTaskId === id) closeTaskDetail();
  });
  window.socket.on('comment:added', (c) => {
    const t = tasks.find(x => x.id === c.taskId);
    if (t) { t.commentCount = (t.commentCount || 0) + 1; renderColumns(); }
    if (activeTaskId === c.taskId) loadComments(c.taskId);
  });
  window.socket.on('project:updated', (p) => {
    if (p.id !== projectId) return;
    project = p;
    renderHeader();
  });
  window.socket.on('project:deleted', ({ id }) => {
    if (id !== projectId) return;
    toast('This project was deleted', 'info');
    window.location.href = '/dashboard.html';
  });
  window.socket.on('typing', ({ taskId, name }) => {
    if (taskId !== activeTaskId) return;
    const el = document.getElementById('typingIndicator');
    el.textContent = `${name} is typing…`;
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => { el.textContent = ''; }, 2000);
  });
}

loadBoard();
subscribeSocket();
